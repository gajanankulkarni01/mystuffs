﻿#include "0105_1009.h"

namespace Test
{

	AINEndpointPropertiesCollectionElement *WebCLientSettingsConfiguration::getAINEndpointPropertiesCollection() const
	{
		return dynamic_cast<AINEndpointPropertiesCollection*>(ConfigurationSection::operator[](L"AINEndpointPropertiesCollection"))
	}

	ConfigurationElement *AINEndpointPropertiesCollectionElement::CreateNewElement()
	{
	return new AINEndpointPropertiesElement();
	}

	AINEndpointPropertiesElement *AINEndpointPropertiesCollectionElement::operator [](const std::wstring &name)
	{
		return dynamic_cast<AINEndpointPropertiesElement*>(BaseGet(Name));
	}

	int AINEndpointPropertiesCollectionElement::IndexOf(AINEndpointPropertiesElement *element)
	{
		return BaseIndexOf(element);
	}

	void AINEndpointPropertiesCollectionElement::Add(AINEndpointPropertiesElement *element)
	{
		BaseAdd(element);
	}

	void AINEndpointPropertiesCollectionElement::BaseAdd(ConfigurationElement *element)
	{
		BaseAdd(element, false);
	}

	void AINEndpointPropertiesCollectionElement::Remove(AINEndpointPropertiesElement *element)
	{
		if (BaseIndexOf(element) >= 0)
		{
			BaseRemove(element->getName());
		}
	}

	void AINEndpointPropertiesCollectionElement::RemoveAt(int index)
	{
		BaseRemoveAt(index);
	}

	void AINEndpointPropertiesCollectionElement::Remove(const std::wstring &name)
	{
		BaseRemove(name);
	}

	void AINEndpointPropertiesCollectionElement::Clear()
	{
		BaseClear();
	}

	std::wstring AINEndpointPropertiesElement::getName() const
	{
		return dynamic_cast<std::wstring>(ConfigurationElementCollection::operator[](L"name"));
	}

	void AINEndpointPropertiesElement::setName(const std::wstring &value)
	{
		ConfigurationElementCollection::operator[](L"name") = value;
	}

	AINEndpointPropertiesElement::AINEndpointPropertiesElement()
	{
	}

	AINEndpointPropertiesElement::AINEndpointPropertiesElement(const std::wstring &elementName)
	{
		setName(elementName);
	}

	ConfigurationElement *AINEndpointPropertiesElement::CreateElement()
	{
		return new AINEndpointPropertyElement();
	}

	std::any AINEndpointPropertiesElement::GetElementKey(ConfigurationElement *element)
	{
		return (static_cast<AINEndpointPropertyElement*>(element))->getKey();
	}

	AINEndpointPropertyElement *AINEndpointPropertiesElement::operator [](const std::wstring &Name)
	{
		return static_cast<AINEndpointPropertyElement*>(BaseGet(Name));
	}

	int AINEndpointPropertiesElement::IndexOf(AINEndpointPropertyElement *prop)
	{
		return BaseIndexOf(prop);
	}

	void AINEndpointPropertiesElement::Add(AINEndpointPropertyElement *prop)
	{
		BaseAdd(prop);
	}

	void AINEndpointPropertiesElement::BaseAdd(COnfigurationElement *element)
	{
		BaseAdd(element, false);
	}

	void AINEndpointPropertiesElement::Remove(AINEndpointPropertyElement *element)
	{
	if (BaseIndexOf(element) >= 0)
	{
		BaseRemove(element->Name);
	}
	}

	void AINEndpointPropertiesElement::RemoveAt(int index)
	{
		BaseRemoveAt(index);
	}

	void AINEndpointPropertiesElement::Remove(const std::wstring &name)
	{
		BaseRemove(name);
	}

	void AINEndpointPropertiesElement::Clear()
	{
		BaseClear();
	}

	AINEndpointPropertyElement::AINEndpointPropertyElement(const std::wstring &key, const std::wstring &value)
	{
		setKey(key);
		setValue(value);
	}

	AINEndpointPropertyElement::AINEndpointPropertyElement()
	{
	}

	AINEndpointPropertyElement::AINEndpointPropertyElement(const std::wstring &elementKey)
	{
		setKey(elementKey);
	}

	std::wstring AINEndpointPropertyElement::getKey() const
	{
		return static_cast<std::wstring>(this->operator[](L"key"));
	}

	void AINEndpointPropertyElement::setKey(const std::wstring &value)
	{
		this->operator[](L"key") = value;
	}

	std::wstring AINEndpointPropertyElement::getValue() const
	{
		return static_cast<std::wstring>(this->operator[](L"value"));
	}

	void AINEndpointPropertyElement::setValue(const std::wstring &value)
	{
		this->operator[](L"value") = value;
	}
}