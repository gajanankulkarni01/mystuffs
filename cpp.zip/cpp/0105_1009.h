﻿#include <string>
#include <any>

//C# TO C++ CONVERTER NOTE: Forward class declarations:
namespace Test { class AINEndpointPropertiesCollectionElement; }
namespace Test { class AINEndpointPropertiesElement; }
namespace Test { class AINEndpointPropertyElement; }

namespace Test
{
	class WebCLientSettingsConfiguration : public ConfigurationSection
	{
	public:
//C# TO C++ CONVERTER NOTE: The following .NET attribute has no direct equivalent in C++:
//ORIGINAL LINE: [ConfigurationProperty("AINEndpointPropertiesCollection", IsDefualtCollection = flase)] public AINEndpointPropertiesCollectionElement AINEndpointPropertiesCollection
		AINEndpointPropertiesCollectionElement *getAINEndpointPropertiesCollection() const;
	};

//C# TO C++ CONVERTER TODO TASK: There is no C++ equivalent to the C# 'typeof' operator:
//C# TO C++ CONVERTER NOTE: The following .NET attribute has no direct equivalent in C++:
//ORIGINAL LINE: [ConfigurationCollection(typeof(AINEndpointPropertiesElement), AddItemName = "AINEndpointProperties", CollectionType = ConfigurationElementCollectionType.BasicMap)] public class AINEndpointPropertiesCollectionElement : ConfigurationElementCollection
	class AINEndpointPropertiesCollectionElement : public ConfigurationElementCollection
	{
	protected:
		ConfigurationElement *CreateNewElement() override;

	public:
		AINEndpointPropertiesElement *operator [](const std::wstring &name);

		int IndexOf(AINEndpointPropertiesElement *element);
		void Add(AINEndpointPropertiesElement *element);
	protected:
		void BaseAdd(ConfigurationElement *element) override;
	public:
		void Remove(AINEndpointPropertiesElement *element);
		void RemoveAt(int index);
		void Remove(const std::wstring &name);
		void Clear();
	};

//C# TO C++ CONVERTER TODO TASK: There is no C++ equivalent to the C# 'typeof' operator:
//C# TO C++ CONVERTER NOTE: The following .NET attribute has no direct equivalent in C++:
//ORIGINAL LINE: [ConfigurationCollection(typeof(AINEndpointPropertyElement), AddItemName = "add", CollectionType = ConfigurationElementCollectionType.BaseMap)] public class AINEndpointPropertiesElement : ConfigurationElementCollection
	class AINEndpointPropertiesElement : public ConfigurationElementCollection
	{
	public:
//C# TO C++ CONVERTER NOTE: The following .NET attribute has no direct equivalent in C++:
//ORIGINAL LINE: [ConfigurationProperty("name", DefaultValue = "EndpointPortType", IsRequired = true, IsKey = true)][StringValidator(InvalidCharacters = "~!@#$%^&*()[]{}/;'\"|\\", MinLength = 1, MaxLength = 60)] public string Name
		std::wstring getName() const;
		void setName(const std::wstring &value);

		AINEndpointPropertiesElement();

		AINEndpointPropertiesElement(const std::wstring &elementName);

	protected:
		ConfigurationElement *CreateElement() override;

		std::any GetElementKey(ConfigurationElement *element) override;

	public:
		AINEndpointPropertyElement *operator [](const std::wstring &Name);

		int IndexOf(AINEndpointPropertyElement *prop);

		void Add(AINEndpointPropertyElement *prop);

	protected:
		void BaseAdd(COnfigurationElement *element) override;

		public:
			void Remove(AINEndpointPropertyElement *element);
		void RemoveAt(int index);
		void Remove(const std::wstring &name);
		void Clear();
	};

	class AINEndpointPropertyElement : public COnfigurationElement
	{
	public:
		AINEndpointPropertyElement(const std::wstring &key, const std::wstring &value);

		AINEndpointPropertyElement();

		AINEndpointPropertyElement(const std::wstring &elementKey);

//C# TO C++ CONVERTER NOTE: The following .NET attribute has no direct equivalent in C++:
//ORIGINAL LINE: [ConfigurationProperty("key", DefaultValue = "Key", IsRequired= true, IsKey = true)] public string Key
		std::wstring getKey() const;
		void setKey(const std::wstring &value);

//C# TO C++ CONVERTER NOTE: The following .NET attribute has no direct equivalent in C++:
//ORIGINAL LINE: [ConfigurationProperty("Value", DefaultValue = "Value", IsRequired= true)] public string Value
		std::wstring getValue() const;
		void setValue(const std::wstring &value);

	};
}